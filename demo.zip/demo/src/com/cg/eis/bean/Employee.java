package com.cg.eis.bean;

public class Employee {
	
	int id;
	double salary;
	String name = new String();
	String designation = new String();
	String insuranceScheme = new String();

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, double salary, String name, String designation, String insuranceScheme) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}


}
