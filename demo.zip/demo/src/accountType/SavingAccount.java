package accountType;

import account.Account;

public class SavingAccount extends Account {
	public int c=24;
	public void show3() {
		super.accountSummary();
		System.out.println(c);
		System.out.println(super.a);
		}

	public SavingAccount() {
		super();
		System.out.println("default saving account");
		
		// TODO Auto-generated constructor stub
	}
	
	
	}


