package accountType;

import account.Account;

public class CurrentAccount extends Account{
	public int b=10,d=5;
	public void show2() {
	System.out.println("current account");
	}
	public void show2(int b) {
		System.out.println(b);
	}
	public void show2(int b, int d) {
		System.out.println(b+d);
	}

	public CurrentAccount() {
		super();
		System.out.println("default current account");
		// TODO Auto-generated constructor stub
	}
	
}
