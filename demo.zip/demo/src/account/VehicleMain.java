package account;

public class VehicleMain {
	public static void main(String[] args) {
		Vehicle c= new Car1();
		c.speed();
		c.fuel();
		c.transport();
		//c.capacity();
		//Vehicle v=new Vehicle(); 
		
	}

}
