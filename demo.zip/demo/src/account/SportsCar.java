package account;

public class SportsCar extends Car {
	
 void move()
 {
	 
	 System.out.println(" for racing on roads");
 }
 int capacity()
 {
	 System.out.println("carries 1 person");
	return 1;
 }
 
 public String task()
	{
		return new String();
		
	}
 String fuel()
 {
	 return "diesel";
 }
}

