package account;

public class Car1 extends Vehicle{

	@Override
	void speed() {
		System.out.println("20kph");
		// TODO Auto-generated method stub
		
	}

	@Override
	void fuel() {
		System.out.println("diesel");
		// TODO Auto-generated method stub
		
	}
	void transport()
	{  
		
		System.out.println("mode is car");
	}
	void capacity()
	{
		System.out.println("3-4");
	}

}
