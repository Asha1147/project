package account;

public class Car {
	
	void move()
	{
		System.out.println("cars move on roads");
	}
	int  capacity()
	{
		System.out.println("carries 2-4 persons");
		return 4;
	}
	
	
	public Object task()
	{
		return new Object();
		
	}
	String fuel()
	{
		
		return "diesel";
	}

	

}
