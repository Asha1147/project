package account;

abstract class Vehicle {
	
	abstract void speed();
	abstract void fuel();
	void transport()
	{
		System.out.println("modes of transport");
	}

}
