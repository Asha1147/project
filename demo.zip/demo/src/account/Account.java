package account;

public class Account {
	public int a=12;
	//final int b;
	  
	public void accountSummary() {
	System.out.println("no summary");	
	
	}

	public Account() {
		System.out.println("default");
		// TODO Auto-generated constructor stub
	}
 
	 

}
