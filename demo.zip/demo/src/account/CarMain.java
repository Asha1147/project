package account;

public class CarMain {
	public static void main(String[] args) {
		SportsCar sc= new SportsCar();
		sc.capacity();
		sc.move();
		String name=sc.fuel();
		System.out.println(name);
	}

}
