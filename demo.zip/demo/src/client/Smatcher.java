package client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Smatcher {
	
	void input1(String name) {
		
		Pattern pat=Pattern.compile("[A-Z][a-z]{2,6}");
		Matcher mat=pat.matcher(name);
		
		System.out.println(mat.matches());
		
	}
void mNo(CharSequence phno) {
		
		Pattern patt=Pattern.compile("[6-9][0-9]{10}");
		Matcher matt=patt.matcher(phno);
		
		System.out.println(matt.matches());
		
	}
void eId(String email) {
	Pattern patte=Pattern.compile("[a-z0-9._+]+@[a-z]+.[a-z]{2,3}");
	Matcher matte=patte.matcher(email);
	
	System.out.println(matte.matches());
	   
}
	
	
	public static void main(String[] args) {
		String input="Shop,Mop,Hopping,Chopping";
		Pattern pattern=Pattern.compile("Hop");
		Matcher matcher=pattern.matcher(input);
		//System.out.println(matcher.matches());
		//while(matcher.find()) {
			//System.out.println(matcher.group()+" "+matcher.start()+" "+matcher.end());
			Smatcher s= new Smatcher();
			//s.input1("A");
			//s.mNo("5814765165");
			s.eId("anusha30@gmail.in");
		}
		
		
	}

//}
