package client;

import accountType.CurrentAccount;
import accountType.SavingAccount;

public class MainAccount {
      public static void main(String[] args) {
		SavingAccount sa= new SavingAccount();
		sa.show3();
		CurrentAccount ca=new CurrentAccount();
		ca.show2();
		ca.show2(10);
		ca.show2(12, 13);
	   
		
	
		
		
	}

}
