package interfaceDemo;

public interface Vehicle3 {
	int a=3;
	void accelerate();

}
