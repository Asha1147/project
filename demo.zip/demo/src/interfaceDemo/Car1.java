package interfaceDemo;

public class Car1 implements Vehicle1,Vehicle2 {

	@Override
	public void speed() {
		System.out.println("3kph");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fuel() {
		System.out.println("diesel");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brake() {
		System.out.println("auto brake");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void accelerate() {
		System.out.println("auto accelerate");
		// TODO Auto-generated method stub
		
	}
	public void start()
	{
		System.out.println("car starts");
	}
  
}
