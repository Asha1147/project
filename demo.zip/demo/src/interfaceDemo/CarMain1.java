package interfaceDemo;

public class CarMain1 {
	public static void main(String[] args) {
		Car1 c= new Car1();
		c.speed();
		c.fuel();
		c.brake();
		c.start();
		
	}

}
