package interfaceDemo;

public interface Vehicle2 extends Vehicle3 {
	
	static public void start()
	{
		System.out.println("vehicle2 starts");
	}
	public default  void brake() {
		System.out.println("vehicle2 brake");
		// TODO Auto-generated method stub
		
	}

}
