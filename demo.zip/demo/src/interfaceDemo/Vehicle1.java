package interfaceDemo;

public interface Vehicle1 {
	public abstract void speed();
	public abstract void fuel();
	default void brake() {
		System.out.println("vehicle brake");
	};
	static void start() {
		System.out.println("vehicle starts");
	}

}
