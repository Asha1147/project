package demo;


public class Person2 {
	
	private String firstName,lastName;
	private char gender;
	 long phoneno;
	
	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public void phno(int phno)
	{
		System.out.println("phone no:"+phno);
	}

	public Person2(String firstName, String lastName) {
		
		this.firstName = firstName;
		this.lastName = lastName;
	
	
	}


	void personDetails()
	{
		
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName );
		
		
	}

}