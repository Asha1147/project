package demo;

public class Addition {
	int a=5, b=10;
	
	 void add()
	{
	
		int result;
		result=a+b;
		System.out.println("result is "+result);
	}

	public static void main(String[] args) {
		Addition ad=new Addition();
	  ad.add();
	}
}
