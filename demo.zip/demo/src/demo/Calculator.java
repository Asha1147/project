package demo;

public class Calculator {

	int a=4,b=1,c;
	public int add() {
		c=a+b;
		
		return c;
	}
	public int sub() {
		c=a-b;
	
		return c;
		
	}
	public int mul() {
		c=a*b;
		
		return c;
		
	}

	
}
