package demo;

public class SwitchExample {
	public static void main(String[] args) {
		String currentDay=args[0];
		switch (currentDay) {
		case "MONDAY":
		case "TUESDAY":
		case "WEDNESDAY":
			System.out.println("boring");
			break;
		case "THURSDAY":
		case "FRIDAY":
		case "SATURDAY":
			System.out.println("fun");
			break;
			default:
				System.out.println("sleep");
				break;
			
		}
	}

}
