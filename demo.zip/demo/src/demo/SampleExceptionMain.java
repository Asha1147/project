package demo;

public class SampleExceptionMain {
	public static void main(String[] args) {
		SampleException se= new SampleException();
		se.divide();
	}

}
