package demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteFile {
	public static void main(String[] args) throws IOException {
		FileOutputStream f=new FileOutputStream("C:\\Users\\anpeddin\\Desktop\\Newfolder\\demo\\name.txt");
		String s="this is a sample program";
		byte[] b=s.getBytes();
		f.write(b);
		f.close();
		FileInputStream fi=new FileInputStream("C:\\Users\\anpeddin\\Desktop\\Newfolder\\demo\\name.txt");
		int a=0;
		while((a=fi.read())!=-1) {
			System.out.print((char) a);
			
			
		}
		fi.close();
		
		
	}


}
