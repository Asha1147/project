package demo;

public class Person1 {
	private String firstName,lastName;
	private char gender;
	 long phoneno;
	
	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public void phno(int phno)
	{
		System.out.println("phone no:"+phno);
	}

	public Person1(String firstName, String lastName, char gender) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	
	}


	void personDetails()
	{
		
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName );
		System.out.println("Gender:"+gender );
		
	}

}

