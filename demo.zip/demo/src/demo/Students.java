package demo;

public class Students extends Persons{
	
	
	void writeExams()
	{
		System.out.println("only student write the exam");
	}
	void sleep(String name)
	{
		super.name=name;
		System.out.println(super.name +"is sleeping 6hr/day");
		System.out.println("----------");
	}
}