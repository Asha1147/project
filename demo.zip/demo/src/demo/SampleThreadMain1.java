package demo;

public class SampleThreadMain1 {
	
	
	public static void main(String[] args) {
		
		/*Thread t1=new Thread(new SampleThread1(),"first");
		Thread t2=new Thread(new SampleThread1(),"second");
		Thread t3=new Thread(new SampleThread1(),"third");
		t1.start();
		try {
			t1.join(1000);
		}catch(Exception e) {
			System.out.println(e);
		}
		
		t2.start();
		try {
			t1.join(1000);
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		t3.start();
		try {
			t1.join();
			t2.join();
			t3.join();
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println(t1.MAX_PRIORITY+" max");
		System.out.println(t1.MIN_PRIORITY+" min");
		System.out.println(t1.NORM_PRIORITY+" norm");
		System.out.println("all threads are dead");*/
		
		
		Thread t=new Thread(new SampleThread1());
		t.start();
	}

}
