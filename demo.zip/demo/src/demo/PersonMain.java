package demo;

public class PersonMain {
	public static void main(String[] args) {
		Person p= new Person("asha","peddina",'f');
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("First Name:"+p.getFirstName());
		System.out.println("Last Name:" +p.getLastName());
		System.out.println("Gender:" +p.getGender());
		
		
	
	}

}