package demo;

import java.util.Scanner;
public class Scan {
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);	
		int upperCharCount=0;
		int lowerCharCount=0;
		
		while(true)
		{
			System.out.println("whats your name");
			String input=scanner.nextLine();
			
			if(!input.isEmpty()) {
			for(char ch:input.toCharArray())
			{
				if (!Character.isDigit(ch) && Character.isAlphabetic(ch))
				{
					if(Character.isUpperCase(ch))
					{
						upperCharCount++;
					}
					else 
					{
						lowerCharCount++;
					}
				
					System.out.println("your name is:"+input);
					System.out.println("uppercase is:"+upperCharCount);
					System.out.println("lowercase is:"+lowerCharCount);
				
			    }
			
			}
			
		}
		scanner.close();
		
	}
	
	}
}

