package demo;

public class Student2 {
	String name;
	int rollno;
	int age;
	
	public Student2(String name, int rollno, int age) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.age = age;
	}

	

}
