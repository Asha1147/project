package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CustomerConnectivity {
	
	String cusName;
	int cusId;
	String gender;
	
	public static void main(String[] args) throws SQLException {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		String cusName=sc.nextLine();
		System.out.println("enter id");
		int cusId=sc.nextInt();
		System.out.println("enter gender");
		String gender=sc.next();
		
	    try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg723","training723");
			PreparedStatement pst=con.prepareStatement("insert into customer values(?,?,?)");
			pst.setString(1,cusName);
			pst.setInt(2, cusId);
			pst.setString(3, gender);
			pst.executeUpdate();
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery("SELECT * FROM customer ");
			while(rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getInt(2));
				System.out.println(rs.getString(3));
				
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
	}


}
