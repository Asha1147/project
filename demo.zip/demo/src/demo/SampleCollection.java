package demo;

import java.util.ArrayList;
import java.util.LinkedList;

public class SampleCollection {
	public static void main(String[] args) {
		ArrayList a=new ArrayList();
		a.add("asha");
		a.add("jvabjb");
		a.add("aghhsd");
		
		a.remove("asha");
		System.out.println(a);
		LinkedList b=new LinkedList();
		b.add(47);
		b.add(11);
	    b.sort(null);
		b.addAll(a);
	
	    
		System.out.println(b);
		System.out.println(a.isEmpty());
		System.out.println(a.get(1));
		
		
	}

}
