package demo;

public class OverrideDemo {
	
		public static void main(String[] args) {
			Students s1=new Students();
			s1.writeExams();
			s1.sleep("student");
			s1.walk();
			Developer d1=new Developer();
			d1.designProj();
			d1.sleep("developer");
		}
	}


