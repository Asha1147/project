package demo;

public class SampleThread1 implements Runnable {
	
	

	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName()+"thread starts");
		for(int row=2;row<5;row++) {
			for(int num=1;num<=10;num++)
				System.out.print(row*num+"");
			System.out.print(" ");
		}
		
		System.out.println(Thread.currentThread().getName()+"thread ends");
		
	}

}
