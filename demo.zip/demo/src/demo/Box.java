package demo;
import static java.lang.Math.*;

public class Box {
	
    double h;
    double b;
    double l;
     int count=0;
    
    
    public Box() {
    	this(2,3,4);
		//super();
		System.out.println("default cons");
		count++;
		System.out.println(count);
		// TODO Auto-generated constructor stub
	}



	public Box(double h, double b, double l) {
		this(2);
		//super();
		this.h = h;
		this.b = b;
		this.l = l;
		System.out.println("default");
		count++;
		System.out.println(count);
	}



	public Box(double h) {
		
		//super();
		this.h = h;
		System.out.println(h);
		count++;
		System.out.println(count);
	}



	static double volume() {
   
    	//return l*b*h;
    	System.out.println(sqrt(4));
     	return 2;
    }
    
}

