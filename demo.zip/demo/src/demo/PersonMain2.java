package demo;

import java.util.Scanner;

public class PersonMain2 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		Person2 p;
		p = new Person2("asha","peddina");
		
		p.personDetails();
		System.out.println("Gender:"+Gender.Female);
		p.phno(n);

}

}
