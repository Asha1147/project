package demo;

public class TrainingClass implements Training {

	@Override
	private int takeSession() {
		// TODO Auto-generated method stub
		
	}

}
