package demo;

public class Condition {
public static void main(String[] args) {
	int a=10;
	if(a<100)
		System.out.println("true");
	else
		System.out.println("false");
}
}
