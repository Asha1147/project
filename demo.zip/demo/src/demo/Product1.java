package demo;

import java.io.Serializable;

public class Product1 implements Serializable {
	int productId;
	String productName;
	double productPrice;
	public Product1(int productId, String productName, double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product1 [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ "]";
	}
	
	

}
