package demo;



class SampleString{
	
	
	/*public void mtd(int...x,int...y) {
		
	}*/
	
	
	
	//public static void main(String[] args) {
		
		/*String s=10>5?"Hello":"Hi";
	System.out.println(s);*/
		/*String a="abc";
		String b=new String("abc");
		String c=a==b?"true":"false";
		System.out.println(c);*/
		/*SampleArray s=new SampleArray();
		System.out.println(s);*/
		
		/*String a="123a";
		Integer.parseInt(a);*/
		/*int a=1000;
		byte b=(byte) a;
		//short c=(short) a;
		System.out.println(b);*/
		
		/*a=126;
		System.out.println(a);*/
		/*Scanner sc=new Scanner(System.in);
		sc.useDelimiter("//");
		System.out.println("enter");
		while(sc.hasNext()) {
			
			String a=sc.next();
		System.out.println(a);
		//sc.next();
		}*/
		
		//System.out.println(-10+20+30+"hi"+10);
		/*LocalDateTime local=LocalDateTime.now();
		System.out.println(local);
		
		LocalDate l=LocalDate.of(2019, 01, 3);
		System.out.println(l);*/
		/*
        Person p;
		HashSet hs=new HashSet( new Person());*/
		
		
		
		
		
		
		
		
		
		
		
	
//}
}