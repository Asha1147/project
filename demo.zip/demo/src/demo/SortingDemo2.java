package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SortingDemo2 {
	public static void main(String[] args) {
		ArrayList<Student2> al=new ArrayList<Student2>();
		al.add(new Student2("asha", 10, 5));
		al.add(new Student2("shasha", 20, 35));
		al.add(new Student2("aaasha", 10, 15));
		Collections.sort(al, new NameComparator());
		Iterator<Student2> iterator=al.iterator();
		while(iterator.hasNext())
		{
			Student2 stu= iterator.next();
			System.out.println(stu.name);
			
		}
		
	//for(Student a:al)
	//{
		//System.out.println(a.age);
		
	//}
	
	//System.out.println("after sorting");
	
}
}