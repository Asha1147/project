package demo;

public class MainMonths {
    public static void main(String[] args) {
		System.out.println(Months.Feb.getDays());
		
	}



}
		
