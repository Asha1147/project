package demo;

public class SampleThread extends Thread{

	
		
	

		static Thread t=new Thread();

		
		public static void main(String[] args) {
			for(int i=0;i<10;i++) {
				try {
					t.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(i);
			}
		}
	
}

