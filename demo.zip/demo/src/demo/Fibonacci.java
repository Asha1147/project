package demo;

public class Fibonacci {
	public static void main(String[] args) {
		  double result;
		    result=5/2;
		    System.out.println(result);

	}

	
	

}
