package demo;

public class SampleException {
	int a=2;
	int b=10;
	void divide()
	{
		int array[]=new int[2];
		try {
			int c=a/b;
			System.out.println(c);
			array[4]=50;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		}
	}


