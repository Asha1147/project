package demo;

public class TraineeMain {
	public static void main(String[] args) {
		Trainee trainee[]=new Trainee[3];
		
			
		trainee[0]=new Trainee(2,"asha",20000);
		trainee[1]=new Trainee(3,"shasha",40000);
		trainee[2]=new Trainee(4,"avi",60000);
		for(int i=0;i<trainee.length;i++) {
			System.out.println(trainee[i]);
		}
		
			
	}

}
