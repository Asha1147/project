package demo;

public enum Months {

	Jan(31),Feb(28),Mar(31);

	int days;
Months(int days){

	this.days=days;
	
}

public int getDays() {
	return days;
}

public void setDays(int days) {
	this.days = days;
}
	
}