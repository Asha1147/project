package demo;

public class Number {
public static void main(String[] args) {
	int num=Integer.parseInt(args[0]);
	if(num>0) {
		System.out.println("Given number is positive");
	}
		else
			System.out.println("Given number is negative");
	
}
}
