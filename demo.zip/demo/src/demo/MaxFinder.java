package demo;

@FunctionalInterface
public interface MaxFinder {
	
	public int maximum(int a, int b);
	
   

	public static void main(String[] args) {
	
		
		MaxFinder finder=(int a, int b)->a>b?a:b;
		int result=finder.maximum(3, 4);
		System.out.println(result);
}
}

