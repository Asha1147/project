package demo;

public class AgeException extends Exception {

	public AgeException(String years) {
		
		System.out.println(years);
		
	}
	 
}
