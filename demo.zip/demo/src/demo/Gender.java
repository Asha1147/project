package demo;

public enum Gender {
	
	Male,Female;

}
