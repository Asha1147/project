package demo;

public class Persons {
	String name;
	
	void sleep(String name) {
		this.name=name;
		System.out.println(this.name+"is sleeping+8hr/day");
		
	}
	void walk()
	{
		System.out.println("this is walk");
		System.out.println("------------");
	
	}
	

}









