package demo;

import java.util.Scanner;

public class PersonMain1 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		Person1 p;
		p = new Person1("asha","peddina",'f');
		p.personDetails();
		p.phno(n);
		
	}

}



