package demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ProductMain1 {
	public static void main(String[] args) throws IOException {
		try(FileOutputStream fos=new FileOutputStream("product");
		ObjectOutputStream oos=new ObjectOutputStream(fos);){
			Product1 p=new Product1(1, "asha", 20000);
			oos.writeObject(p);
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
		try(FileInputStream fis=new FileInputStream("product");
				ObjectInputStream ois=new ObjectInputStream(fis);){
					
					Product1 p1=(Product1) ois.readObject();
					System.out.println(p1.productId+"  "+p1.productName+"  "+p1.productPrice);
					
					
				}
				catch(Exception e) {
					System.out.println(e);
				}
		
		
	}

}
