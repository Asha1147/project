package demo;

public class Print {
//	 int i=0;
//	void numbers() {
//	
//i++;
//	 
//	 if(i<=20) {
//		 System.out.println(i);
//		
//		 numbers();
//		 
//	 }
	
	
	public static void main(String[] args) {
		//Print p=new Print();
		//p.numbers();
		int i=1;
		 if(i<=20) {
		 System.out.println(i++);

		 main(null);
		 
		 }
		 }

	}
	 //goto if;
	



