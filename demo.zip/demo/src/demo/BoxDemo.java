package demo;

public class BoxDemo {

		 public static void main(String[] args) {
		Box box;
		box= new Box();
		b
		//Box box1=new Box(10, 20, 30);
	   // double result=Box.volume();	
	    //System.out.println(result);
		//Box b=new Box(23);
		Product p =new Product();
		p.setProductId(2);
		p.setProductName("asha");
		p.setProductPrice("4000");
		System.out.println(p);
		System.out.println(p.getProductId());
	}

}
