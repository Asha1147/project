package demo;

import java.util.Scanner;

public class AgeExceptionMain {
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		System.out.println("enter age");
		int years=s.nextInt();
		try
		{
			if(years<10)
				throw new AgeException("invalid age");
			else
				System.out.println("valid age");
		}
		catch(AgeException e) {
			System.out.println(e);
		}
		
	}

}
