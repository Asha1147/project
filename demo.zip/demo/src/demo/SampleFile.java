package demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SampleFile {
	public static void main(String[] args) throws IOException {
		FileOutputStream fos=new FileOutputStream("C:\\Users\\anpeddin\\Desktop\\Newfolder\\demo\\name.txt");
		DataOutputStream dos=new DataOutputStream(fos);
		dos.writeByte(Byte.MAX_VALUE);
		dos.writeShort(Short.MAX_VALUE);
		dos.writeDouble(Double.MAX_VALUE);
		dos.writeBoolean(true);
		FileInputStream fis=new FileInputStream("C:\\Users\\anpeddin\\Desktop\\Newfolder\\demo\\name.txt");
		DataInputStream dis= new DataInputStream(fis);
		System.out.println(dis.readByte());
		System.out.println(dis.readShort());
		System.out.println(dis.readDouble());
		System.out.println(dis.readBoolean());
		
	}

}
