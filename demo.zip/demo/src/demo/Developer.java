package demo;

public class Developer extends Persons
{
	 void designProj()
	 {
		  System.out.println("design the project");
	 }
	 void sleep(String name)
	 {
		 super.name=name;
		 System.out.println(super.name +"is sleeping 4hr/day");
		 System.out.println("-----------");
	 }
}