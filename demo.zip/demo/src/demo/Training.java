package demo;

@FunctionalInterface
public interface Training {
	public void  takeSession();

}
