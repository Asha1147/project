package demo;

public class Trainee {
		int empid;
		String empName;
	    int salary;
	public Trainee(int empid, String empName, int salary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Trainee [empid=" + empid + ", empName=" + empName + ", salary=" + salary + "]";
	}
	
		
	}
	
	


