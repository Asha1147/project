package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingDemo {
	public static void main(String[] args) {
		ArrayList<Student> al=new ArrayList<Student>();
		al.add(new Student("asha", 10, 5));
		al.add(new Student("shasha", 20, 35));
		al.add(new Student("aaasha", 10, 15));
		Collections.sort(al);
	for(Student a:al)
	{
		System.out.println(a.age);
		
	}
	
	System.out.println("after sorting");
	
}
}