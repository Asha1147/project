package demo;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	Calculator c=new Calculator();

	
	
	@Test
	void testAdd() {
		assertEquals(5,c.add());
		
	}

	@Test
	void testSub() {
		assertEquals(3, c.sub());
	}

	@Test
	void testMul() {
		assertEquals(4, c.mul());
	}
	
	
	@After
	@Test
	 void testA1() {
		System.out.println("after");
		
		}
    
	@Before
	@Test
	 void testA2() {
		System.out.println("before");
	}
	
	
	@BeforeClass
	@Test
	 void testA3() {
		System.out.println("before class");
	}
	@AfterClass
	@Test
	
       void testA4() {
		System.out.println("after class");
	}
	
	@Ignore
	@Test
	 public static void testA5() {
		
		System.out.println("ignore");
	}
	

}
