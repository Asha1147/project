package demo;

public class SampleThread2 {
	
		   public static void main(String[] args) {
		     
			   ThreadCubbyHole c = new ThreadCubbyHole();
		      ThreadProducer p1 = new ThreadProducer(c, 1);
		      ThreadConsumer c1 = new ThreadConsumer(c, 1);
		      p1.start(); 
		      c1.start();
		   }
		}
		

          
		
		

