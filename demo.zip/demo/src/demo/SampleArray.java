package demo;

import java.util.Arrays;

public class SampleArray {
  public static void main(String[] args) {
	int a=5;
	int[] array= new int[5];
	array[0]=20;
	array[1]=30;
	array[2]=40;
	for(int index: array) {
		System.out.print(" "+index);
		
		
		}
	int result=Arrays.binarySearch(array, 30);
	System.out.println(result);
	int[] array1=Arrays.copyOf(array,10);
	for(int index1:array1)
	{
		System.out.print(" "+index1);
	}
	System.out.println(Arrays.copyOfRange(array1, 1, 10));
}
  
  
}
