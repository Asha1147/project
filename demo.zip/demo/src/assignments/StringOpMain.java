package assignments;

import java.util.Scanner;

public class StringOpMain {
	public static void main(String[] args) {
		String str1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		str1=sc.nextLine();
		int option;
		System.out.println("enter option");
		option=sc.nextInt();
		StringOp s= new StringOp();
		s.stringOperation(str1,option);
	}

}
