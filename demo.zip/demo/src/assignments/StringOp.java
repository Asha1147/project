package assignments;

import java.util.Scanner;

public class StringOp {
	public void stringOperation(String str1,int option) {
		
		
		
		switch(option)
		{
		case 1: str1=str1.concat(str1);
			    System.out.println("string after concatenation:"+str1);
		        break;
		        
		case 2: String str2=str1;
				for(int i=0;i<str1.length();i++)
		          {  
					if(i%2==1) {
		        	str2=str1.replace(str1.charAt(i),'#');
		          }
			
	             	}
		         System.out.println("string after adding #"+str2);
		         break;
		case 3: str1=removeDuplicate(str1);
		        System.out.println("string after removing duplicates"+str1);
		        break;
		default:
			str1="option not available";
			System.out.println(str1);
			  
		}
		
	}

	private String removeDuplicate(String str2) {
		String result="";
		for(int i=0;i<str2.length();i++)
		{
			 if(!result.contains(String.valueOf(str2.charAt(i))))
			 {
				 result +=String.valueOf(str2.charAt(i));
			 }
		}
	return result;
	}
	
}



