package assignments;

import java.util.Scanner;

public class ExceptionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Exception2 six1=new Exception2();
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter First Name");
			String fName=scan.nextLine();
			System.out.println("Enter Last Name");
			String lName=scan.nextLine();
			six1.PersonClass(fName, lName, 'M');
			
		
	}

}
