package assignments;

import java.util.Scanner;

public class AcceptDateMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter date in dd/MM/yyyy format:");
		String input=sc.nextLine();
	    AcceptDate ad=new AcceptDate();
		ad.aDate(input);
		
	}

}
