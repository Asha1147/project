package assignments;

public class AcceptZoneIdMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AcceptZoneId az=new AcceptZoneId();
		az.zone("America/New_York");
		az.zone("Europe/London");
		az.zone("Asia/Tokyo");
		az.zone("US/Pacific");
		az.zone("Africa/Cairo");
		az.zone("Australia/Sydney");
	}

}
