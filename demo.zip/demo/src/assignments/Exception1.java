package assignments;



public class Exception1 extends Exception {
	
	public Exception1(String exp)
	{
		System.out.println(exp);
	}

}

