package assignments;

import java.util.Scanner;

public class StringPNMain {
	public static void main(String[] args) {
		String str1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string:");
		str1=sc.nextLine();
		StringPN s=new StringPN();
		s.StringP(str1);
	}

}
