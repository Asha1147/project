package assignments;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ProductPurchaseDate {

	public void expiry(String name,int month,int years) {
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localdate=LocalDate.parse(name,formatter);
		
		System.out.println("Purchased date:"+localdate);
		LocalDate local1=localdate.plusMonths(month);
		LocalDate local2=local1.plusYears(years);
		System.out.println("Expiry date"+local2);
}
}
