package assignments;

import java.util.Scanner;

public class TwoAcceptDatesMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first date in dd/MM/yyyy format:");
		String input=sc.nextLine();
		System.out.println("enter second date in dd/MM/yyyy format:");
		String input1=sc.nextLine();
		TwoAcceptDates tad=new TwoAcceptDates();
		tad.twoAccept(input,input1);
	}

}
