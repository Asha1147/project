package assignments;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class AcceptZoneId {

	public void zone(String zoneId)
	{
		ZonedDateTime date=ZonedDateTime.now(ZoneId.of(zoneId));
		System.out.println(date);
	}
}
