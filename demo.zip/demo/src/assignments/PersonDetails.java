package assignments;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class PersonDetails {
	
	public void age(String dob)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localdate=LocalDate.now();
		LocalDate enteredDate=LocalDate.parse(dob,formatter);
		Period period=Period.between(enteredDate, localdate);
		System.out.println("Age is :"+period.getYears());
	}
	
	public String fullName(String fName,String lName)
	{
		String fullName1=fName.concat(lName);
		return fullName1;
		
	}

}
