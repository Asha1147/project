package assignments;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class TwoAcceptDates {
	public void twoAccept(String input,String input1)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate inputDate=LocalDate.parse(input,formatter);
		
		LocalDate localDate=LocalDate.parse(input1,formatter);
		Period period=Period.between(inputDate, localDate);
		System.out.println("Duration Between in Days "+period.getDays());
		System.out.println("Duration Between in Months "+period.toTotalMonths());
		System.out.println("Duration Between in years "+period.getYears());
		
	}

	

}
