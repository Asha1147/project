package assignments;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class AcceptDate {
	
	public void aDate(String input) {
		
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    LocalDate inputdate=LocalDate.parse(input, formatter);
	    LocalDate localDate=LocalDate.now();
		Period period=Period.between(inputdate, localDate);
		System.out.println("Duration Between in Days "+period.getDays());
		System.out.println("Duration Between in Months "+period.toTotalMonths());
		System.out.println("Duration Between in years "+period.getYears());
		
	}

}
