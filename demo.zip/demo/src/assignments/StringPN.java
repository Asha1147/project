package assignments;



public class StringPN {

		
	
	void StringP(String str1) {
	int count=0;
	char[] array=str1.toCharArray();
	for(int i=1;i<array.length;i++) {
		if(Character.toLowerCase(array[i-1])>(Character.toLowerCase(array[i]))) 
			count++;
		}
		if(count==0) {
			System.out.println("String is positive");
			
		}
		else
			System.out.println("String is negative");
	}
	
	}


