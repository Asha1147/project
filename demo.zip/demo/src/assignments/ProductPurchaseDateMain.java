package assignments;

import java.util.Scanner;

public class ProductPurchaseDateMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter product purchase date:");
		String date=scan.nextLine();
		System.out.println("enter warranty duration in months and years");
		int month=scan.nextInt();
		int years=scan.nextInt();
		ProductPurchaseDate ppd=new ProductPurchaseDate();
		ppd.expiry(date, month, years);
	}

}
