package com.cg.bsa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.bsa.bean.ProductBean;
import com.cg.bsa.util.DBConnection;

public class ProductDaoImpl implements IProductDao{
	
	Logger logger=Logger.getRootLogger();
	public ProductDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}

	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, Exception {
		Connection connection=DBConnection.getConnection();
		ProductBean productBean=new ProductBean();
		//int queryResult=0;
		try
		
		{
			int pCode=0;
			Statement statement=connection.createStatement();
			System.out.println("3");
			ResultSet resultSet=statement.executeQuery("select product_code from product");
			while(resultSet.next())
			{
					 pCode=resultSet.getInt(1);
					 System.out.println();
					 if(productCode==pCode)
					 {
						 pCode=productCode;
						 break;
					 }
					 pCode=0;
			}
					if(productCode==pCode)
					{
						
						System.out.println("4");
			PreparedStatement prepareStatement=connection.prepareStatement("select * from product where product_code=?");
			prepareStatement.setInt(1,productCode);
			
			ResultSet resultSet1=prepareStatement.executeQuery();
			while(resultSet1.next())
			{
				productBean.setProductCode(resultSet1.getInt(1));
				productBean.setProductName(resultSet1.getString(2));
				productBean.setProductCategory(resultSet1.getString(3));
				productBean.setProductDescription(resultSet1.getString(4));
				productBean.setProductPrice(resultSet1.getInt(5));
				
			}
			
			if(resultSet1==null)
			{
				logger.error("retrieve failed ");
				throw new Exception("retrieving failed ");

			}
			else
			{
				logger.info("retrieved successfully:");
				return productBean;
			}
			
					}else {
						
						return null;
					}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
		
		
		
		
		
		
		
		
		
		
		
		return productBean;
	}

	@Override
	public boolean insertSalesDetails(ProductBean bean) throws ClassNotFoundException, SQLException, Exception {
		
Connection connection=DBConnection.getConnection();
		
		try                                                                
		{
			int queryResult=0;
			int quantity=bean.getQuantity();
			int total=bean.getProductPrice()*quantity;
			bean.setLineTotal(total);
		
			PreparedStatement prepareStatement=connection.prepareStatement("insert into sales values(sales_seq.nextval,?,?,sysdate,?)");
			prepareStatement.setInt(1,bean.getProductCode());
			prepareStatement.setInt(2, quantity);
			prepareStatement.setLong(3,total);
			queryResult=prepareStatement.executeUpdate();	
			
			
			if(queryResult==0)
			{
				logger.error("insertion failed ");
				throw new Exception("inserting details failed ");

			}
			else
			{
				logger.info("inserted successfully:");
				
			}
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		
		
		
		return true;
		
		
	}

}
