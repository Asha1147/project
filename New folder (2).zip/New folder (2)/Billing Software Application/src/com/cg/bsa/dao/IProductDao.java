package com.cg.bsa.dao;

import java.sql.SQLException;

import com.cg.bsa.bean.ProductBean;

public interface IProductDao {

	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, Exception;

	public boolean insertSalesDetails(ProductBean bean) throws ClassNotFoundException, SQLException, Exception;

}
