create table Customer_Details(
    seatno number,
    name varchar2(30),
    email varchar2(40),
    phoneno varchar2(10),
    age number,
   gender varchar2(10),
    noofseats number);



 create sequence Seat_sequence
    start with 1
    maxvalue 30
    nocycle;



