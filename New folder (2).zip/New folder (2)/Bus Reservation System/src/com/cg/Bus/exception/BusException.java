package com.cg.Bus.exception;

public class BusException extends Exception {

	public BusException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
