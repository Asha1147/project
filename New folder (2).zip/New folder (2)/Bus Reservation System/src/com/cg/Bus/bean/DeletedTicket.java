package com.cg.Bus.bean;

public class DeletedTicket {
	private int seatno;

	public int getSeatno() {
		return seatno;
	}

	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}

	@Override
	public String toString() {
		return "DeletedTicket [seatno=" + seatno + "]";
	}


	
}
