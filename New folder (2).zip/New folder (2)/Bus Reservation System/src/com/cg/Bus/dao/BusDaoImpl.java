package com.cg.Bus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.Bus.bean.BusBean;
import com.cg.Bus.bean.DeletedTicket;
import com.cg.Bus.exception.BusException;
import com.cg.Bus.util.DBConnection;

public class BusDaoImpl implements IBusDAO{

	Logger logger=Logger.getRootLogger();
	public BusDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@Override
	public BusBean cancelTicket(int seatNo) throws ClassNotFoundException, SQLException, Exception {
		
		int a=seatNo;
        int queryResult=0;
		Connection connection=DBConnection.getConnection();
	
		PreparedStatement st=connection.prepareStatement(QueryMapper.CANCEL_TICKET);
		st.setInt(1, a);
		queryResult=st.executeUpdate();
		DeletedTicket delete=new DeletedTicket();
				BusBean bean=new BusBean();
		
	
		try
		{
			delete.setSeatno(a);
		deletedticket(delete);
		if(queryResult==0)
		{
			logger.error("deletion failed ");
			throw new BusException("delete again ");

		}
		else
		{
			logger.info("bus details deleted successfully:");
			
		}
		
		
	
	
		}catch(Exception e)
		{
			logger.error("cancel ticket failed");
			e.printStackTrace();
		}
		return bean;
		
	}
    public void deletedticket(DeletedTicket delete) throws ClassNotFoundException, SQLException, Exception {
    	Connection connection=DBConnection.getConnection();
		Statement st=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		int i=0;
		preparedStatement=connection.prepareStatement(QueryMapper.DELETED_TICKET);
		preparedStatement.setInt(1, delete.getSeatno());
       i= preparedStatement.executeUpdate();
       if(i!=0) {
    	   logger.info("added deleted tickets into deleted ticket table");
    	   System.out.println("*added");
       }
    }


	@Override
	public int bookTicket(BusBean bus) throws BusException {
		int queryResult;
		int seatNo=0;
		try {
			Connection connection=DBConnection.getConnection();
			Statement st=null;
			Statement st1=null;
			PreparedStatement preparedStatement=null;
			PreparedStatement ps=null;
			ResultSet resultSet=null;
			ResultSet rs=null;
			st1=connection.createStatement();
	        rs= st1.executeQuery(QueryMapper.DELETED_SEATNO);
			
			for(int i=0;i<bus.getNoOfSeats();i++) {
				if(!rs.next()) {
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_CUSTOMER);
				preparedStatement.setString(1,bus.getName());
				preparedStatement.setString(2,bus.getEmail());
				preparedStatement.setString(3,bus.getPhoneno());
				preparedStatement.setInt(4,bus.getAge());
				preparedStatement.setString(5,bus.getGender());
				preparedStatement.setInt(6,bus.getNoOfSeats());
				queryResult=preparedStatement.executeUpdate();
			
				st=connection.createStatement();
				resultSet=st.executeQuery(QueryMapper.SEAT_SEQUENCE);
				while(resultSet.next()) {
					seatNo =	(resultSet.getInt(1));
					
				
			}if(queryResult==0)
			{
				logger.error("Booking failed ");
				throw new BusException("Booking bus details failed ");

			}
			else
			{
				logger.info("Booking done successfully:");
				return seatNo;
			}	
				//return seatNo;
			}
				else {
					
					DeletedTicket dt=new DeletedTicket();
					dt.setSeatno(rs.getInt(1));
					int val=dt.getSeatno();
					preparedStatement=connection.prepareStatement(QueryMapper.INSERT_CUSTOMER1);
					preparedStatement.setInt(1,dt.getSeatno());
					preparedStatement.setString(2,bus.getName());
					preparedStatement.setString(3,bus.getEmail());
					preparedStatement.setString(4,bus.getPhoneno());
					preparedStatement.setInt(5,bus.getAge());
					preparedStatement.setString(6,bus.getGender());
					preparedStatement.setInt(7,bus.getNoOfSeats());
					queryResult=preparedStatement.executeUpdate();
					PreparedStatement pst=connection.prepareStatement(QueryMapper.DELETE_SEATNO);
				     pst.setInt(1, val);
					 pst.executeUpdate();
					String str=bus.getPhoneno();
					resultSet=st.executeQuery(QueryMapper.VIEW_DETAILS);
					
					while(resultSet.next()) {
						seatNo =	(resultSet.getInt(1));
							
					
				}
					if(queryResult==0)
					{
						logger.error("Booking failed ");
						throw new BusException("Booking bus details failed ");

					}
					else
					{
						logger.info("Booking done successfully:");
						return seatNo;
					}	
					//return seatNo;
				}
					
				}
		}
			catch(Exception e) {
				System.out.println(e);
			}
			
			
		
	
	return (Integer) null;
}
	@Override
	public BusBean viewTicketDetails(int seatNo) throws ClassNotFoundException, SQLException, Exception {
		int b=seatNo;
		Connection connection=DBConnection.getConnection();
		PreparedStatement pst=connection.prepareStatement(QueryMapper.VIEW_TICKET_DETAILS);
		pst.setInt(1, b); 
		Statement s=connection.createStatement();
		BusBean bean=new BusBean();
		int y=0;
		int x=0;
		ResultSet rs=s.executeQuery(QueryMapper.VIEW_DETAILS);
		while(rs.next())
		{
			x=rs.getInt(1);
		
		if(x==b)
		{
		
		try
		{
		
		
		ResultSet resultSet = pst.executeQuery();
			while(resultSet.next())
			{
			bean.setSeatno(resultSet.getInt(1));
			bean.setName(resultSet.getString(2));
			bean.setEmail(resultSet.getString(3));
			bean.setPhoneno(resultSet.getString(4));
			bean.setAge(resultSet.getInt(5));
			bean.setGender(resultSet.getString(6));
			bean.setNoOfSeats(resultSet.getInt(7));
			y=123;
			}
			if(!rs.next()) {
				logger.error("enter valid seatno");
			}
			else {
				logger.info("details viewed successfully");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
				
		}
				
		}
		if(y==0)
		{
			System.out.println("Enter valid ticket number.");
		}
		 return bean;
		 
	}
	@Override
	public int checkAvailability(int seatAvail) throws ClassNotFoundException, SQLException, Exception {
		Connection connection=DBConnection.getConnection();
		Statement st=connection.createStatement();
		try 
		{
			ResultSet resultSet = st.executeQuery(QueryMapper.CHECK_AVAILABILITY);
			while(resultSet.next()) {
				seatAvail =(resultSet.getInt(1));
					
			
		}
			
		}
		catch(Exception e) {
			logger.error("exception");
			e.printStackTrace();
		}
		return seatAvail;
	}
}
