package com.cg.Bus.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.Bus.bean.BusBean;
import com.cg.Bus.dao.BusDaoImpl;
import com.cg.Bus.exception.BusException;

public class BusDaoTest {
	
	static BusDaoImpl dao;
	static BusBean bus;
    

    @Before
	public static void initialize() {
		System.out.println("in before class"); 
		dao = new BusDaoImpl();
		bus = new BusBean();
	}



    @Test
    public void testBookTicket() throws BusException {

	assertNotNull(dao.bookTicket(bus));

}
    
    @Ignore
	@Test
	public void testBookTicket1() throws BusException {
		// increment the number next time you test for positive test case
		assertEquals(1, dao.bookTicket(bus));
	}
    
  /*  @Test
	public void testBookTicket2() throws BusException {

		bus.("Shashwathi");
		bus.setPhoneNumber("9876543210");
		bus.setAddress("whitefield");
		bus.setDonationAmount(5000);
		assertTrue("Data Inserted successfully",
				dao.bookTicket(bus) > 1);

	}*/
    
    @Test
	public void testViewTicketDetails() throws ClassNotFoundException, SQLException, Exception {
		assertNotNull(dao.viewTicketDetails(3));
	}

    
    
    
    
    
    
    
    
    
    
    

}